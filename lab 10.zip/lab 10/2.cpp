#include <iostream>
using namespace std;
int main()
{
    const int size = 8;
    int array[size] = {3, 2, 1, 6, 20, 4, 9, 10};
    int *ptr = array;
    cout << " VALUES IS PRINT THROUGHT NORMAL INDEXS\n";
    for (int i = 0; i < size; i++)
    {
        cout << i << "   ";
        cout << array[i];
        cout << endl;
    }
    cout << " VALUES IS PRINT THROUGHT POINTER INDEXS\n";
    for (int i = 0; i < size; i++)
    {
        cout << i << "   ";
        cout << *(ptr + i);
        cout << endl;
    }
    *ptr = *(ptr + 2);
    cout << *ptr << "\t\t" << *(ptr + 4) << "\t\t" << *(ptr + 6);
    return 0;
}