#include <iostream>
using namespace std;
void swapJawad(int *ptrAnum1, int *ptrBnum2);
int main()
{

    const int size = 2;
    int num1 = 0;
    int num2 = 0;

    cout << " ENTER A VALUE ONE ";
    cin >> num1;
    cout << " ENTER A VALUE TWO ";
    cin >> num2;
    cout << " \n--------------VALUE IS BEFORE SWAP----------------\n";
    cout << " num1 value is BEFORE is swapping is " << num1;
    cout << endl;
    cout << " num2 value is BEFORE is swapping is " << num2;
    cout << endl;
    int *ptrAnum1 = &num1;
    int *ptrBnum2 = &num2;
    swapJawad(&num1, &num2);
    cout << " \n -------------VALUE IS AFTER SWAP----------- \n";
    cout << " num1 value is after is swapping is " << num1;
    cout << endl;
    cout << " num2 value is after is swapping is " << num2;
    cout << endl;

    return 0;
}
void swapJawad(int *ptrAnum1, int *ptrBnum2)
{
    *ptrAnum1 = *ptrAnum1 + *ptrBnum2;
    *ptrBnum2 = *ptrAnum1 - *ptrBnum2;
    *ptrAnum1 = *ptrAnum1 - *ptrBnum2;
}