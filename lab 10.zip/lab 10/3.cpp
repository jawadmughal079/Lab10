#include <iostream>
using namespace std;
int main()
{
    int size = 0;
    cout << " ENTER A SIZE OF ARRAY : ";
    cin >> size;
    int array[size] = {0};
    for (int i = 0; i < size; i++)
    {
        cout << " ENTER  A " << i + 1 << " VALUE  ";
        cin >> array[i];
    }
    int *ptr = array;
    for (int i = 0; i < size; i++)
    {
        cout << "    " << i + 1 << " VALUE  IS ";
        cout << *(ptr + i) << "   ";
        cout<<endl;
    }

    return 0;
}