#include <iostream>
using namespace std;
void inputValueIntoArray(int *array, int size);
void outputValueIntoArray(int *array, int size);
int findMax(int *array, int size, int counter[], int &max);
int frequencyFinder(int *array, int size, int counter[], int max, int &max2);
int main()
{
    int size = 0;
    cout << "ENTER A SIZE OF ARRAY : ";
    cin >> size;
    int max = 0;
    int max2 = 0;
    int *array = new int[size];
    int counter[size] = {0};

    inputValueIntoArray(array, size);
    outputValueIntoArray(array, size);
    findMax(array, size, counter, max);
    cout << " max frequecny is : " << max;
    cout << endl;
    frequencyFinder(array, size, counter, max, max2);
    cout << " max number is : " << max2 << "     "
         << " frequency is : " << max;
    return 0;
}

void inputValueIntoArray(int *array, int size)
{

    for (int i = 0; i < size; i++)
    {
        cout << "ENTER A " << i + 1 << " VALUE ";
        cin >> *(array + i);
    }
}
void outputValueIntoArray(int *array, int size)
{
    cout << "\n VALUE YOU ENTERED INTO ARRAY \n";
    for (int i = 0; i < size; i++)
    {
        cout << " A " << i + 1 << " VALUE ";
        cout << *(array + i);
        cout << endl;
    }
}
int findMax(int *array, int size, int counter[], int &max)
{

    for (int i = 0; i < size; i++)
    {
        int j = 0;
        for (j = 0; j < size; j++)
        {
            if (array[i] == array[j])
            {
                counter[i]++;
            }
        }

        if (max < counter[i])
        {
            max = counter[i];
        }
    }
    return max;
}
int frequencyFinder(int *array, int size, int counter[], int max, int &max2)
{
    int maxNumberArray[size] = {0};
    int total = 0;

    for (int i = 0; i < size; i++)
    {
        int j = 0;
        for (j = 0; j < size; j++)
        {
            if (array[i] == array[j])
            {
                break;
            }
        }
        if (i == j)
        {
            if (counter[i] == max)
            {
                maxNumberArray[total++] = array[i];
            }
        }
    }
    for (int i = 0; i < total; i++)
    {

        if (maxNumberArray[i] > max2)
        {
            max2 = maxNumberArray[i];
        }
    }
    return max2;
}