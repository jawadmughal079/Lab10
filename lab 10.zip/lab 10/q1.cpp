#include <iostream>
using namespace std;
int main()
{
    const int size = 2;
    int a = 0;
    int b = 0;

    cout << " ENTER A  FIRST VALUE  : ";
    cin >> a;
    cout << " ENTER A  SECOND VALUE  : ";
    cin >> b;
    int *ptrA = &a;
    int *ptrB = &b;
    cout << "FIRST VALUE  : ";
    cout << *ptrA;
    cout << endl;
    cout << "SECOND VALUE  :";
    cout << *ptrB;
    return 0;
}