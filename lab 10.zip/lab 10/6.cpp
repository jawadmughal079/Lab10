#include <iostream>
using namespace std;
void inputValuesIntoArray(double *array, double size);
int calculateAvg(double *array, double size);
void displayValuesIofArray(double *array, double size);
int main()
{
    int total = 0;
    int size = 0;
    double avg = 0;
    cout << "How many days of sales figures to process? : ";
    cin >> size;
    double *array = new double[size];
    inputValuesIntoArray(array, size);
    avg = calculateAvg(array, size);
    displayValuesIofArray(array, size);

    cout << " Average Sales:" << avg / size;
    return 0;
}
void inputValuesIntoArray(double *array, double size)
{
    for (int i = 0; i < size; i++)
    {
        cout << " Day " << i + 1 << " : ";
        cin >> *(array + i);
        while (array[i] < 0)
        {
            cout << " Day " << i + 1 << " : ";
            cout << endl;
            cout << " Please enter a postive sale ";
            cin >> *(array + i);
        }
    }
}
int calculateAvg(double *array, double size)
{
    double avg = 0;
    for (int i = 0; i < size; i++)
    {

        avg += *(array + i);
    }
    return avg;
}
void displayValuesIofArray(double *array, double size)
{
    for (int i = 0; i < size; i++)
    {
        cout << " Day  " << i + 1 << "  Sales: ";
        cout << *(array + i);
        cout << endl;
    }
}
